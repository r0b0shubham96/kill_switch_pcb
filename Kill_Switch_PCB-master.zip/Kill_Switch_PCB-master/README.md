# Kill_Switch_PCB

This Repo Contains all the Stuff related to the Kill Switch PCB : 

- Schematics ( .sch ) 
- Board ( .brd ) 
- Library (for KF part ) 
- Gerber File 

